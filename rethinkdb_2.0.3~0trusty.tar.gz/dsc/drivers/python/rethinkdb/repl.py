# This file exists solely as a place to store a single global object,
# the connection set by calling `connection.repl()` and used by
# `query.run()`.

default_connection = None
