
#include <termcap.h>
int main(){ tgetent(0, "xterm"); return 0; }


