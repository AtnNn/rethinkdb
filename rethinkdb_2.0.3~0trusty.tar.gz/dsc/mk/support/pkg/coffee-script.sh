
npm_package=coffee-script
version=1.7.1

include npm-pkg.inc
