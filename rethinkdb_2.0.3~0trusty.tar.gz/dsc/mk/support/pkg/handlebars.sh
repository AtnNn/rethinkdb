
npm_package=handlebars
version=1.3.0

include npm-pkg.inc
