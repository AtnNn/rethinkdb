
npm_package=browserify
version=3.24.13

include npm-pkg.inc
