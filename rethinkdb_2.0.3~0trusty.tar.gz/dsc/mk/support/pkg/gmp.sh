
version=6.0.0a

src_url=https://ftp.gnu.org/gnu/gmp/gmp-$version.tar.bz2

