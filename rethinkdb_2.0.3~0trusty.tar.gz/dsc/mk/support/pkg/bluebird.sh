
npm_package=bluebird
version=2.3.2

include npm-pkg.inc
