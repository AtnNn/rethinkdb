
npm_package=less
version=1.6.2

include npm-pkg.inc
