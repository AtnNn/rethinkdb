
version=0.10.15

src_url=http://nodejs.org/dist/v$version/node-v$version.tar.gz
